

$('.element').slideDown();

var element = $('.element');
if (element.length) {
    element.slideDown(); // this is a heavy call
}
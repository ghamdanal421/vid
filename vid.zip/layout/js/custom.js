/* global $, alert, console, mixitup,  scrollTop */


$(function () {
    'use strict';
    // start asidebar



    // end asidebar

   
	
});
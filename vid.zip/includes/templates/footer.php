		<!-- Start Footer -->
		<footer>
			<div class="container aside">
			
                <div class="copyright">جميع الحقوق محفوظة  &copy; <?php echo "2020" ?> لمنصة VID </div>
			</div>
        </footer>
        <!-- End Footer -->
		<script src="<?php echo $js ?>jquery-min.js"></script>
		<script src="<?php echo $js ?>jquery.bxslider.min.js"></script>
		<script src="<?php echo $js ?>custom.js"></script>
	</body>
</html>